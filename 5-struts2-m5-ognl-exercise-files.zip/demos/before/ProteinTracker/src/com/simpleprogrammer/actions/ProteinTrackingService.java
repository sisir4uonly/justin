package com.simpleprogrammer.actions;

public class ProteinTrackingService {

	public void AddProtein(int enteredProtein) {
		// TODO Auto-generated method stub
		
	}

}
